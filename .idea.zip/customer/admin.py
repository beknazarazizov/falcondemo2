from django.contrib import admin

from app.models import Product
from customer.models import Customer

# Register your models here.
admin.site.register(Customer)
